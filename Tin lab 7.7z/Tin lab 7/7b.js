const fs = require('fs');
const path = "./TIN7/";


fs.watch(path, (eventType, filename) => {
    if (eventType === "change") {
        try {
            console.log(fs.readFileSync(filename,'utf8'))
        } catch (ignored) {}
    }
});